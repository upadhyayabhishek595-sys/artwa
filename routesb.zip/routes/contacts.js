const express = require('express');
const router = express.Router();
const { pool } = require('../config/database');
const { verifyClient } = require('../middleware/auth');

// GET /api/contacts
router.get('/', verifyClient, async (req, res) => {
    try {
        const { page = 1, limit = 20, search } = req.query;
        const offset = (page - 1) * limit;

        let where = 'WHERE client_id = ?';
        let params = [req.client.id];

        if (search) {
            where += ' AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)';
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        const [contacts] = await pool.execute(
            `SELECT * FROM contacts ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, parseInt(limit), parseInt(offset)]
        );

        const [countRows] = await pool.execute(
            `SELECT COUNT(*) as total FROM contacts ${where}`, params
        );

        res.json({
            success: true,
            data: contacts,
            pagination: {
                total: countRows[0].total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(countRows[0].total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/contacts/:id
router.get('/:id', verifyClient, async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT * FROM contacts WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        if (!rows.length) return res.status(404).json({ success: false, message: 'Contact not found' });
        res.json({ success: true, data: rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/contacts
router.post('/', verifyClient, async (req, res) => {
    try {
        const { name, phone, email, notes } = req.body;

        if (!phone) return res.status(400).json({ success: false, message: 'Phone required' });

        const [existing] = await pool.execute(
            'SELECT id FROM contacts WHERE client_id = ? AND phone = ?',
            [req.client.id, phone]
        );
        if (existing.length) return res.status(400).json({ success: false, message: 'Contact already exists' });

        const [result] = await pool.execute(
            'INSERT INTO contacts (client_id, name, phone, email, notes) VALUES (?, ?, ?, ?, ?)',
            [req.client.id, name, phone, email, notes]
        );

        res.status(201).json({ success: true, message: 'Contact created', data: { id: result.insertId } });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PATCH /api/contacts/:id
router.patch('/:id', verifyClient, async (req, res) => {
    try {
        const { name, email, notes } = req.body;

        await pool.execute(
            'UPDATE contacts SET name = ?, email = ?, notes = ? WHERE id = ? AND client_id = ?',
            [name, email, notes, req.params.id, req.client.id]
        );

        res.json({ success: true, message: 'Contact updated' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/contacts/:id
router.delete('/:id', verifyClient, async (req, res) => {
    try {
        await pool.execute(
            'DELETE FROM contacts WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        res.json({ success: true, message: 'Contact deleted' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;