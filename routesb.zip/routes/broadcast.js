const express = require('express');
const router = express.Router();
const axios = require('axios');
const { pool } = require('../config/database');
const { verifyClient } = require('../middleware/auth');

// =============================================
// CREATE BROADCAST
// POST /api/broadcast
// =============================================
router.post('/', verifyClient, async (req, res) => {
    try {
        const {
            name,
            template_id,
            phone_number_id,
            contact_ids,
            tag,
            scheduled_at
        } = req.body;

        if (!name || !template_id || !phone_number_id) {
            return res.status(400).json({
                success: false,
                message: 'name, template_id and phone_number_id required'
            });
        }

        // Verify template belongs to client and is approved
        const [templateRows] = await pool.execute(
            'SELECT * FROM templates WHERE id = ? AND client_id = ?',
            [template_id, req.client.id]
        );
        if (!templateRows.length) {
            return res.status(404).json({ success: false, message: 'Template not found' });
        }

        // Verify phone number belongs to client
        const [phoneRows] = await pool.execute(
            'SELECT * FROM phone_numbers WHERE id = ? AND client_id = ? AND status = "active"',
            [phone_number_id, req.client.id]
        );
        if (!phoneRows.length) {
            return res.status(404).json({ success: false, message: 'Phone number not found' });
        }

        // Get contacts — either by IDs or by tag
        let contacts = [];
        if (contact_ids && contact_ids.length > 0) {
            const placeholders = contact_ids.map(() => '?').join(',');
            const [rows] = await pool.execute(
                `SELECT id, phone, name FROM contacts 
                 WHERE client_id = ? AND id IN (${placeholders}) 
                 AND opted_in = 1 AND is_blocked = 0`,
                [req.client.id, ...contact_ids]
            );
            contacts = rows;
        } else if (tag) {
            const [rows] = await pool.execute(
                `SELECT id, phone, name FROM contacts 
                 WHERE client_id = ? AND opted_in = 1 AND is_blocked = 0
                 AND JSON_CONTAINS(tags, ?)`,
                [req.client.id, JSON.stringify(tag)]
            );
            contacts = rows;
        } else {
            // All opted-in contacts
            const [rows] = await pool.execute(
                `SELECT id, phone, name FROM contacts 
                 WHERE client_id = ? AND opted_in = 1 AND is_blocked = 0`,
                [req.client.id]
            );
            contacts = rows;
        }

        if (!contacts.length) {
            return res.status(400).json({ success: false, message: 'No eligible contacts found' });
        }

        // Create broadcast record
        const [result] = await pool.execute(
            `INSERT INTO broadcasts 
             (client_id, phone_number_id, template_id, name, status, total_contacts, scheduled_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                req.client.id, phone_number_id, template_id, name,
                scheduled_at ? 'draft' : 'running',
                contacts.length,
                scheduled_at || null
            ]
        );

        const broadcastId = result.insertId;

        // Insert broadcast contacts
        for (const contact of contacts) {
            await pool.execute(
                'INSERT INTO broadcast_contacts (broadcast_id, contact_id) VALUES (?, ?)',
                [broadcastId, contact.id]
            );
        }

        res.status(201).json({
            success: true,
            message: scheduled_at
                ? `Broadcast scheduled for ${scheduled_at}`
                : 'Broadcast started',
            data: {
                id: broadcastId,
                total_contacts: contacts.length,
                status: scheduled_at ? 'draft' : 'running'
            }
        });

        // If not scheduled, start sending immediately
        if (!scheduled_at) {
            processBroadcast(broadcastId, templateRows[0], phoneRows[0], contacts);
        }

    } catch (error) {
        console.error('❌ Create broadcast error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// PROCESS BROADCAST (background job)
// =============================================
const processBroadcast = async (broadcastId, template, phoneRecord, contacts) => {
    try {
        console.log(`🚀 Starting broadcast ${broadcastId} to ${contacts.length} contacts`);

        await pool.execute(
            'UPDATE broadcasts SET started_at = NOW(), status = "running" WHERE id = ?',
            [broadcastId]
        );

        let sentCount = 0;
        let failedCount = 0;

        for (const contact of contacts) {
            try {
                // Rate limit — Meta allows 80 messages/sec, we do 10/sec to be safe
                await sleep(100);

                const payload = buildTemplatePayload(contact, template, phoneRecord.phone_number_id);

                const metaRes = await axios.post(
                    `https://graph.facebook.com/v25.0/${phoneRecord.phone_number_id}/messages`,
                    payload,
                    {
                        headers: {
                            'Authorization': `Bearer ${phoneRecord.access_token}`,
                            'Content-Type': 'application/json'
                        },
                        timeout: 10000
                    }
                );

                const wamid = metaRes.data?.messages?.[0]?.id;

                await pool.execute(
                    `UPDATE broadcast_contacts 
                     SET status = 'sent', wamid = ?, sent_at = NOW()
                     WHERE broadcast_id = ? AND contact_id = ?`,
                    [wamid, broadcastId, contact.id]
                );

                sentCount++;

                // Update sent count every 10 messages
                if (sentCount % 10 === 0) {
                    await pool.execute(
                        'UPDATE broadcasts SET sent_count = ? WHERE id = ?',
                        [sentCount, broadcastId]
                    );
                    console.log(`📤 Broadcast ${broadcastId}: ${sentCount}/${contacts.length} sent`);
                }

            } catch (err) {
                failedCount++;
                const errorMsg = err.response?.data?.error?.message || err.message;

                await pool.execute(
                    `UPDATE broadcast_contacts 
                     SET status = 'failed', error_message = ?
                     WHERE broadcast_id = ? AND contact_id = ?`,
                    [errorMsg, broadcastId, contact.id]
                );

                console.error(`❌ Failed to send to ${contact.phone}:`, errorMsg);
            }
        }

        // Mark broadcast complete
        await pool.execute(
            `UPDATE broadcasts 
             SET status = 'completed', sent_count = ?, failed_count = ?, completed_at = NOW()
             WHERE id = ?`,
            [sentCount, failedCount, broadcastId]
        );

        console.log(`✅ Broadcast ${broadcastId} completed: ${sentCount} sent, ${failedCount} failed`);

    } catch (error) {
        console.error('❌ Broadcast processing error:', error);
        await pool.execute(
            'UPDATE broadcasts SET status = "failed" WHERE id = ?',
            [broadcastId]
        );
    }
};

// =============================================
// BUILD TEMPLATE PAYLOAD
// =============================================
const buildTemplatePayload = (contact, template, phoneNumberId) => {
    const components = [];

    // Header component
    if (template.header_type && template.header_content) {
        if (template.header_type === 'text') {
            components.push({
                type: 'header',
                parameters: [{ type: 'text', text: template.header_content }]
            });
        } else if (['image', 'video', 'document'].includes(template.header_type)) {
            components.push({
                type: 'header',
                parameters: [{
                    type: template.header_type,
                    [template.header_type]: { link: template.header_content }
                }]
            });
        }
    }

    // Body variables — replace {{name}} with contact name etc.
    const variables = template.variables
        ? (typeof template.variables === 'string'
            ? JSON.parse(template.variables)
            : template.variables)
        : [];

    if (variables.length > 0) {
        const bodyParams = variables.map(v => ({
            type: 'text',
            text: v === '{{name}}' ? (contact.name || contact.phone) : v
        }));
        components.push({ type: 'body', parameters: bodyParams });
    }

    // Buttons
    const buttons = template.buttons
        ? (typeof template.buttons === 'string'
            ? JSON.parse(template.buttons)
            : template.buttons)
        : [];

    buttons.forEach((btn, index) => {
        if (btn.type === 'url' && btn.url_suffix) {
            components.push({
                type: 'button',
                sub_type: 'url',
                index: String(index),
                parameters: [{ type: 'text', text: btn.url_suffix }]
            });
        }
    });

    return {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: contact.phone.replace('+', ''),
        type: 'template',
        template: {
            name: template.name,
            language: { code: template.language || 'en_US' },
            components: components.length > 0 ? components : undefined
        }
    };
};

// =============================================
// HELPER
// =============================================
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// =============================================
// GET ALL BROADCASTS
// GET /api/broadcast
// =============================================
router.get('/', verifyClient, async (req, res) => {
    try {
        const { page = 1, limit = 20, status } = req.query;
        const offset = (page - 1) * limit;

        let where = 'WHERE b.client_id = ?';
        let params = [req.client.id];

        if (status) { where += ' AND b.status = ?'; params.push(status); }

        const [broadcasts] = await pool.execute(
            `SELECT b.*, t.name as template_name, p.phone_number as from_number
             FROM broadcasts b
             LEFT JOIN templates t ON b.template_id = t.id
             LEFT JOIN phone_numbers p ON b.phone_number_id = p.id
             ${where}
             ORDER BY b.created_at DESC
             LIMIT ? OFFSET ?`,
            [...params, parseInt(limit), parseInt(offset)]
        );

        const [countRows] = await pool.execute(
            `SELECT COUNT(*) as total FROM broadcasts b ${where}`, params
        );

        res.json({
            success: true,
            data: broadcasts,
            pagination: {
                total: countRows[0].total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(countRows[0].total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// GET BROADCAST DETAILS + STATS
// GET /api/broadcast/:id
// =============================================
router.get('/:id', verifyClient, async (req, res) => {
    try {
        const [rows] = await pool.execute(
            `SELECT b.*, t.name as template_name, p.phone_number as from_number
             FROM broadcasts b
             LEFT JOIN templates t ON b.template_id = t.id
             LEFT JOIN phone_numbers p ON b.phone_number_id = p.id
             WHERE b.id = ? AND b.client_id = ?`,
            [req.params.id, req.client.id]
        );

        if (!rows.length) {
            return res.status(404).json({ success: false, message: 'Broadcast not found' });
        }

        // Get contact-level stats
        const [contactStats] = await pool.execute(
            `SELECT bc.status, COUNT(*) as count
             FROM broadcast_contacts bc
             WHERE bc.broadcast_id = ?
             GROUP BY bc.status`,
            [req.params.id]
        );

        res.json({
            success: true,
            data: {
                ...rows[0],
                stats: contactStats
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// GET BROADCAST CONTACTS
// GET /api/broadcast/:id/contacts
// =============================================
router.get('/:id/contacts', verifyClient, async (req, res) => {
    try {
        const { status, page = 1, limit = 50 } = req.query;
        const offset = (page - 1) * limit;

        let where = 'WHERE bc.broadcast_id = ?';
        let params = [req.params.id];

        if (status) { where += ' AND bc.status = ?'; params.push(status); }

        const [contacts] = await pool.execute(
            `SELECT bc.*, c.phone, c.name
             FROM broadcast_contacts bc
             JOIN contacts c ON bc.contact_id = c.id
             ${where}
             ORDER BY bc.id DESC
             LIMIT ? OFFSET ?`,
            [...params, parseInt(limit), parseInt(offset)]
        );

        res.json({ success: true, data: contacts });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// PAUSE BROADCAST
// PATCH /api/broadcast/:id/pause
// =============================================
router.patch('/:id/pause', verifyClient, async (req, res) => {
    try {
        await pool.execute(
            'UPDATE broadcasts SET status = "paused" WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        res.json({ success: true, message: 'Broadcast paused' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;