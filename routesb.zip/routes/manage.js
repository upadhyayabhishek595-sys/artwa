const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { pool } = require('../config/database');
const { verifyAdmin, verifyClient } = require('../middleware/auth');

// =============================================
// ADMIN - CLIENT MANAGEMENT
// =============================================

// GET /api/manage/clients
router.get('/clients', verifyAdmin, async (req, res) => {
    try {
        const { page = 1, limit = 20, status, search } = req.query;
        const offset = (page - 1) * limit;

        let where = 'WHERE 1=1';
        let params = [];

        if (status) { where += ' AND c.status = ?'; params.push(status); }
        if (search) {
            where += ' AND (c.name LIKE ? OR c.email LIKE ? OR c.business_name LIKE ?)';
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        const [clients] = await pool.execute(
            `SELECT c.id, c.name, c.email, c.business_name, c.phone,
                    c.status, c.trial_ends_at, c.last_login, c.created_at,
                    p.name as plan_name
             FROM clients c
             LEFT JOIN plans p ON c.plan_id = p.id
             ${where}
             ORDER BY c.created_at DESC
             LIMIT ? OFFSET ?`,
            [...params, parseInt(limit), parseInt(offset)]
        );

        const [countRows] = await pool.execute(
            `SELECT COUNT(*) as total FROM clients c ${where}`, params
        );

        res.json({
            success: true,
            data: clients,
            pagination: {
                total: countRows[0].total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(countRows[0].total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PATCH /api/manage/clients/:id/status
router.patch('/clients/:id/status', verifyAdmin, async (req, res) => {
    try {
        const { status } = req.body;
        const validStatuses = ['active', 'suspended', 'trial', 'inactive'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, message: 'Invalid status' });
        }
        await pool.execute('UPDATE clients SET status = ? WHERE id = ?', [status, req.params.id]);
        res.json({ success: true, message: `Client ${status}` });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// CLIENT - AGENT MANAGEMENT
// =============================================

// GET /api/manage/agents
router.get('/agents', verifyClient, async (req, res) => {
    try {
        const [agents] = await pool.execute(
            'SELECT id, name, email, role, status, last_login, created_at FROM agents WHERE client_id = ?',
            [req.client.id]
        );
        res.json({ success: true, data: agents });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/manage/agents
router.post('/agents', verifyClient, async (req, res) => {
    try {
        const { name, email, password, role = 'agent' } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ success: false, message: 'Name, email and password required' });
        }

        const [existing] = await pool.execute('SELECT id FROM agents WHERE email = ?', [email]);
        if (existing.length) return res.status(400).json({ success: false, message: 'Email already in use' });

        const hashedPassword = await bcrypt.hash(password, 10);
        const [result] = await pool.execute(
            'INSERT INTO agents (client_id, name, email, password, role) VALUES (?, ?, ?, ?, ?)',
            [req.client.id, name, email, hashedPassword, role]
        );

        res.status(201).json({ success: true, message: 'Agent created', data: { id: result.insertId } });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/manage/agents/:id
router.delete('/agents/:id', verifyClient, async (req, res) => {
    try {
        await pool.execute(
            'UPDATE agents SET status = "inactive" WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        res.json({ success: true, message: 'Agent deactivated' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// TEMPLATES
// =============================================

// GET /api/manage/templates
router.get('/templates', verifyClient, async (req, res) => {
    try {
        const [templates] = await pool.execute(
            'SELECT * FROM templates WHERE client_id = ? ORDER BY created_at DESC',
            [req.client.id]
        );
        res.json({ success: true, data: templates });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/manage/templates
router.post('/templates', verifyClient, async (req, res) => {
    try {
        const { name, category, language, components } = req.body;

        if (!name || !category || !components) {
            return res.status(400).json({ success: false, message: 'name, category and components required' });
        }

        const [result] = await pool.execute(
            `INSERT INTO templates (client_id, name, category, language, components, status)
             VALUES (?, ?, ?, ?, ?, 'pending')`,
            [req.client.id, name, category, language || 'en_US', JSON.stringify(components)]
        );

        res.status(201).json({ success: true, message: 'Template created', data: { id: result.insertId } });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/manage/templates/:id
router.delete('/templates/:id', verifyClient, async (req, res) => {
    try {
        await pool.execute(
            'DELETE FROM templates WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        res.json({ success: true, message: 'Template deleted' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =============================================
// API KEYS
// =============================================

// GET /api/manage/api-keys
router.get('/api-keys', verifyClient, async (req, res) => {
    try {
        const [keys] = await pool.execute(
            `SELECT id, name, key_prefix, permissions, last_used, expires_at, created_at 
             FROM api_keys WHERE client_id = ? AND status = 'active'`,
            [req.client.id]
        );
        res.json({ success: true, data: keys });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/manage/api-keys
router.post('/api-keys', verifyClient, async (req, res) => {
    try {
        const { name, permissions = ['read', 'write'], expires_at } = req.body;

        if (!name) return res.status(400).json({ success: false, message: 'Name required' });

        const apiKey = 'ak_' + crypto.randomBytes(32).toString('hex');
        const keyPrefix = apiKey.substring(0, 10) + '...';
        const hashedKey = crypto.createHash('sha256').update(apiKey).digest('hex');

        const [result] = await pool.execute(
            `INSERT INTO api_keys (client_id, name, api_key, key_prefix, permissions, expires_at)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [req.client.id, name, hashedKey, keyPrefix, JSON.stringify(permissions), expires_at || null]
        );

        // Return the raw key ONCE — never shown again
        res.status(201).json({
            success: true,
            message: 'API key created. Save it now — it will not be shown again.',
            data: { id: result.insertId, api_key: apiKey, key_prefix: keyPrefix }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/manage/api-keys/:id
router.delete('/api-keys/:id', verifyClient, async (req, res) => {
    try {
        await pool.execute(
            'UPDATE api_keys SET status = "revoked" WHERE id = ? AND client_id = ?',
            [req.params.id, req.client.id]
        );
        res.json({ success: true, message: 'API key revoked' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;