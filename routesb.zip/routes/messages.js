const express = require('express');
const router = express.Router();
const axios = require('axios');
const { pool } = require('../config/database');
const { verifyClient, verifyAgent } = require('../middleware/auth');

// =============================================
// SEND MESSAGE
// POST /api/messages/send
// =============================================
router.post('/send', verifyClient, async (req, res) => {
    try {
        const {
            conversation_id,
            type = 'text',
            body,
            media_url,
            media_id,
            caption,
            template_name,
            template_data,
            location_lat,
            location_lng,
            location_name
        } = req.body;

        if (!conversation_id) {
            return res.status(400).json({ success: false, message: 'conversation_id required' });
        }

        // Get conversation + phone number details
        const [convRows] = await pool.execute(
            `SELECT c.*, p.phone_number_id, p.access_token, p.phone_number
             FROM conversations c
             JOIN phone_numbers p ON c.phone_number_id = p.id
             WHERE c.id = ? AND c.client_id = ?`,
            [conversation_id, req.client.id]
        );

        if (!convRows.length) {
            return res.status(404).json({ success: false, message: 'Conversation not found' });
        }

        const conv = convRows[0];

        // Get contact phone
        const [contactRows] = await pool.execute(
            'SELECT phone FROM contacts WHERE id = ?',
            [conv.contact_id]
        );
        const toPhone = contactRows[0].phone;

        // Build Meta API payload
        let metaPayload = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: toPhone
        };

        switch (type) {
            case 'text':
                metaPayload.type = 'text';
                metaPayload.text = { body };
                break;
            case 'image':
                metaPayload.type = 'image';
                metaPayload.image = media_id
                    ? { id: media_id, caption }
                    : { link: media_url, caption };
                break;
            case 'video':
                metaPayload.type = 'video';
                metaPayload.video = media_id
                    ? { id: media_id, caption }
                    : { link: media_url, caption };
                break;
            case 'audio':
                metaPayload.type = 'audio';
                metaPayload.audio = media_id
                    ? { id: media_id }
                    : { link: media_url };
                break;
            case 'document':
                metaPayload.type = 'document';
                metaPayload.document = media_id
                    ? { id: media_id, caption }
                    : { link: media_url, caption };
                break;
            case 'location':
                metaPayload.type = 'location';
                metaPayload.location = {
                    latitude: location_lat,
                    longitude: location_lng,
                    name: location_name
                };
                break;
            case 'template':
                metaPayload.type = 'template';
                metaPayload.template = {
                    name: template_name,
                    language: { code: template_data?.language || 'en_US' },
                    components: template_data?.components || []
                };
                break;
            default:
                return res.status(400).json({ success: false, message: `Unsupported type: ${type}` });
        }

        // Send to Meta API
        const metaRes = await axios.post(
            `https://graph.facebook.com/v25.0/${conv.phone_number_id}/messages`,
            metaPayload,
            {
                headers: {
                    'Authorization': `Bearer ${conv.access_token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const wamid = metaRes.data?.messages?.[0]?.id;

        // Save to DB
       const [result] = await pool.execute(
    `INSERT INTO messages 
     (conversation_id, client_id, wamid, direction, type, body,
      media_url, media_id, caption, location_lat, location_lng, location_name,
      template_name, template_data, status, sent_by_api, timestamp)
     VALUES (?, ?, ?, 'outbound', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'sent', 1, NOW())`,
    [
        conversation_id, req.client.id, wamid, type,
        body || null,
        media_url || null,
        media_id || null,
        caption || null,
        location_lat || null,
        location_lng || null,
        location_name || null,
        template_name || null,
        template_data ? JSON.stringify(template_data) : null
    ]
);

        // Update conversation last message
        await pool.execute(
            `UPDATE conversations SET last_message = ?, last_message_at = NOW() WHERE id = ?`,
            [body || `[${type}]`, conversation_id]
        );

        res.json({
            success: true,
            message: 'Message sent successfully',
            data: { id: result.insertId, wamid }
        });

    } catch (error) {
        console.error('❌ Send message error:', error.response?.data || error.message);
        res.status(500).json({
            success: false,
            message: 'Failed to send message',
            error: error.response?.data || error.message
        });
    }
});

// =============================================
// GET MESSAGES FOR CONVERSATION
// GET /api/messages/:conversation_id
// =============================================
router.get('/:conversation_id', verifyClient, async (req, res) => {
    try {
        const { conversation_id } = req.params;
        const { page = 1, limit = 50 } = req.query;
        const offset = (page - 1) * limit;

        // Verify conversation belongs to client
        const [convCheck] = await pool.execute(
            'SELECT id FROM conversations WHERE id = ? AND client_id = ?',
            [conversation_id, req.client.id]
        );
        if (!convCheck.length) {
            return res.status(404).json({ success: false, message: 'Conversation not found' });
        }

        const [messages] = await pool.execute(
            `SELECT m.*, 
                    a.name as agent_name
             FROM messages m
             LEFT JOIN agents a ON m.sent_by_agent_id = a.id
             WHERE m.conversation_id = ?
             ORDER BY m.timestamp DESC
             LIMIT ? OFFSET ?`,
            [conversation_id, parseInt(limit), parseInt(offset)]
        );

        const [countRows] = await pool.execute(
            'SELECT COUNT(*) as total FROM messages WHERE conversation_id = ?',
            [conversation_id]
        );

        res.json({
            success: true,
            data: messages.reverse(),
            pagination: {
                total: countRows[0].total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(countRows[0].total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;