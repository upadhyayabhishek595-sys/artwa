const jwt = require('jsonwebtoken');
const { pool } = require('../config/database');

// =============================================
// TOKEN VERIFICATION
// =============================================

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

// =============================================
// ROLE VERIFIERS
// =============================================

const verifyAdmin = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== 'admin') {
      return res.status(403).json({ success: false, message: 'Admin access required' });
    }

    // Fetch fresh admin from DB
    const [rows] = await pool.execute(
      'SELECT id, name, email, role, status FROM admins WHERE id = ? AND status = "active"',
      [decoded.id]
    );

    if (!rows.length) {
      return res.status(403).json({ success: false, message: 'Admin not found or inactive' });
    }

    req.user = decoded;
    req.admin = rows[0];
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

const verifyClient = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== 'client') {
      return res.status(403).json({ success: false, message: 'Client access required' });
    }

    // Fetch fresh client from DB
    const [rows] = await pool.execute(
      `SELECT c.id, c.name, c.email, c.business_name, c.phone, c.status,
              c.trial_ends_at, c.plan_id,
              p.name as plan_name, p.api_access, p.message_limit,
              p.agent_limit, p.chatbot_access, p.broadcast_access
       FROM clients c
       LEFT JOIN plans p ON c.plan_id = p.id
       WHERE c.id = ?`,
      [decoded.id]
    );

    if (!rows.length) {
      return res.status(403).json({ success: false, message: 'Client not found' });
    }

    const client = rows[0];

    if (client.status === 'suspended') {
      return res.status(403).json({ success: false, message: 'Account suspended. Contact support.' });
    }

    req.user = decoded;
    req.client = client;
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

const verifyAgent = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== 'agent') {
      return res.status(403).json({ success: false, message: 'Agent access required' });
    }

    // Fetch fresh agent from DB
    const [rows] = await pool.execute(
      `SELECT a.id, a.name, a.email, a.role, a.status, a.client_id,
              c.name as client_name, c.business_name
       FROM agents a
       JOIN clients c ON a.client_id = c.id
       WHERE a.id = ? AND a.status != 'inactive'`,
      [decoded.id]
    );

    if (!rows.length) {
      return res.status(403).json({ success: false, message: 'Agent not found or inactive' });
    }

    req.user = decoded;
    req.agent = rows[0];
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

// =============================================
// OPTIONAL: Admin can also access client routes
// =============================================

const verifyClientOrAdmin = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type === 'admin') {
      const [rows] = await pool.execute(
        'SELECT id, name, email, role, status FROM admins WHERE id = ? AND status = "active"',
        [decoded.id]
      );
      if (!rows.length) {
        return res.status(403).json({ success: false, message: 'Admin not found or inactive' });
      }
      req.user = decoded;
      req.admin = rows[0];
      return next();
    }

    if (decoded.type === 'client') {
      const [rows] = await pool.execute(
        `SELECT c.id, c.name, c.email, c.business_name, c.status, c.plan_id,
                p.name as plan_name, p.api_access, p.message_limit
         FROM clients c
         LEFT JOIN plans p ON c.plan_id = p.id
         WHERE c.id = ?`,
        [decoded.id]
      );
      if (!rows.length) {
        return res.status(403).json({ success: false, message: 'Client not found' });
      }
      if (rows[0].status === 'suspended') {
        return res.status(403).json({ success: false, message: 'Account suspended.' });
      }
      req.user = decoded;
      req.client = rows[0];
      return next();
    }

    return res.status(403).json({ success: false, message: 'Access denied' });
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

module.exports = {
  authenticateToken,
  verifyAdmin,
  verifyClient,
  verifyAgent,
  verifyClientOrAdmin,
  // Legacy aliases (in case used anywhere)
  isAdmin: verifyAdmin,
  isClient: verifyClient,
};