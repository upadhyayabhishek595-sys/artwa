import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

import Login from './pages/Login';
import AdminLogin from './pages/AdminLogin';
import Register from './pages/Register';
import ClientLayout from './layouts/ClientLayout';
import AdminLayout from './layouts/AdminLayout';

import ClientDashboard from './pages/client/Dashboard';
import Inbox from './pages/client/Inbox';
import Contacts from './pages/client/Contacts';
import Broadcasts from './pages/client/Broadcasts';
import Templates from './pages/client/Templates';
import Agents from './pages/client/Agents';
import ClientSettings from './pages/client/Settings';

import AdminDashboard from './pages/admin/Dashboard';
import AdminClients from './pages/admin/Clients';
import AdminSettings from './pages/admin/Settings';

const App = () => {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Toaster position="top-right" />
                <Routes>
                    {/* Public */}
                    <Route path="/"              element={<Navigate to="/login" />} />
                    <Route path="/login"         element={<Login />} />
                    <Route path="/register"      element={<Register />} />
                    <Route path="/admin/login"   element={<AdminLogin />} />

                    {/* Client Routes */}
                    <Route path="/" element={
                        <ProtectedRoute requiredType="client">
                            <ClientLayout />
                        </ProtectedRoute>
                    }>
                        <Route path="dashboard"  element={<ClientDashboard />} />
                        <Route path="inbox"      element={<Inbox />} />
                        <Route path="contacts"   element={<Contacts />} />
                        <Route path="broadcasts" element={<Broadcasts />} />
                        <Route path="templates"  element={<Templates />} />
                        <Route path="agents"     element={<Agents />} />
                        <Route path="settings"   element={<ClientSettings />} />
                    </Route>

                    {/* Admin Routes */}
                    <Route path="/admin" element={
                        <ProtectedRoute requiredType="admin">
                            <AdminLayout />
                        </ProtectedRoute>
                    }>
                        <Route path="dashboard" element={<AdminDashboard />} />
                        <Route path="clients"   element={<AdminClients />} />
                        <Route path="settings"  element={<AdminSettings />} />
                    </Route>
                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
};

export default App;