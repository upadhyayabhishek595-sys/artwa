import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ProtectedRoute = ({ children, requiredType }) => {
    const { user, loading } = useAuth();

    if (loading) return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
            Loading...
        </div>
    );

    if (!user) return <Navigate to="/login" />;
    if (requiredType && user.type !== requiredType) {
        return <Navigate to={user.type === 'admin' ? '/admin/dashboard' : '/dashboard'} />;
    }

    return children;
};

export default ProtectedRoute;