import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';
import toast from 'react-hot-toast';
import { Key, Lock, Phone, Plus, Trash2 } from 'lucide-react';

const Settings = () => {
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState('profile');
    const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm: '' });
    const [apiKeyForm, setApiKeyForm] = useState({ name: '' });
    const [apiKeys, setApiKeys] = useState([]);
    const [newKey, setNewKey] = useState(null);
    const [loading, setLoading] = useState(false);

    // Phone numbers state
    const [phones, setPhones] = useState([]);
    const [phoneForm, setPhoneForm] = useState({ phone_number_id: '', phone_number: '', display_name: '', access_token: '' });
    const [showAddPhone, setShowAddPhone] = useState(false);

    const loadApiKeys = async () => {
        try {
            const r = await api.get('/manage/api-keys');
            setApiKeys(r.data.data || []);
        } catch (err) { console.error(err); }
    };

    const loadPhones = async () => {
        try {
            const r = await api.get('/manage/phone-numbers');
            setPhones(r.data.data || []);
        } catch (err) { console.error(err); }
    };

    // Fixed: useEffect not useState
    useEffect(() => {
        loadApiKeys();
        loadPhones();
    }, []);

    const changePassword = async (e) => {
        e.preventDefault();
        if (pwForm.new_password !== pwForm.confirm) {
            return toast.error('Passwords do not match');
        }
        setLoading(true);
        try {
            await api.post('/auth/change-password', {
                current_password: pwForm.current_password,
                new_password: pwForm.new_password
            });
            toast.success('Password changed successfully');
            setPwForm({ current_password: '', new_password: '', confirm: '' });
        } catch (err) {
            toast.error(err.response?.data?.message || 'Error');
        } finally { setLoading(false); }
    };

    const createApiKey = async (e) => {
        e.preventDefault();
        try {
            const r = await api.post('/manage/api-keys', apiKeyForm);
            setNewKey(r.data.data.api_key);
            toast.success('API key created');
            setApiKeyForm({ name: '' });
            loadApiKeys();
        } catch (err) {
            toast.error(err.response?.data?.message || 'Error');
        }
    };

    const revokeKey = async (id) => {
        if (!confirm('Revoke this API key?')) return;
        await api.delete(`/manage/api-keys/${id}`);
        toast.success('Key revoked');
        loadApiKeys();
    };

    const addPhone = async (e) => {
        e.preventDefault();
        try {
            await api.post('/manage/phone-numbers', phoneForm);
            toast.success('Phone number added');
            setShowAddPhone(false);
            setPhoneForm({ phone_number_id: '', phone_number: '', display_name: '', access_token: '' });
            loadPhones();
        } catch (err) {
            toast.error(err.response?.data?.message || 'Error');
        }
    };

    const removePhone = async (id) => {
        if (!confirm('Remove this phone number?')) return;
        await api.delete(`/manage/phone-numbers/${id}`);
        toast.success('Phone number removed');
        loadPhones();
    };

    const tabs = [
        { id: 'profile',  label: 'Profile',       icon: <Phone size={15} /> },
        { id: 'phones',   label: 'Phone Numbers',  icon: <Phone size={15} /> },
        { id: 'password', label: 'Password',       icon: <Lock size={15} /> },
        { id: 'apikeys',  label: 'API Keys',       icon: <Key size={15} /> },
    ];

    return (
        <div>
            <h2 style={{ margin: '0 0 24px', fontSize: '20px', fontWeight: '600' }}>Settings</h2>

            <div style={{ display: 'flex', gap: '24px' }}>
                {/* Tab nav */}
                <div style={s.tabNav}>
                    {tabs.map(t => (
                        <button key={t.id} onClick={() => setActiveTab(t.id)}
                            style={{ ...s.tabBtn, ...(activeTab === t.id ? s.tabBtnActive : {}) }}>
                            {t.icon} {t.label}
                        </button>
                    ))}
                </div>

                <div style={s.content}>
                    {/* Profile */}
                    {activeTab === 'profile' && (
                        <div style={s.card}>
                            <h3 style={s.cardTitle}>Profile Information</h3>
                            <div style={s.infoGrid}>
                                {[
                                    { label: 'Name',       value: user?.name },
                                    { label: 'Email',      value: user?.email },
                                    { label: 'Business',   value: user?.business_name },
                                    { label: 'Plan',       value: user?.plan },
                                    { label: 'Status',     value: user?.status },
                                    { label: 'Trial Ends', value: user?.trial_ends_at ? new Date(user.trial_ends_at).toLocaleDateString() : '—' },
                                ].map(item => (
                                    <div key={item.label} style={s.infoItem}>
                                        <div style={s.infoLabel}>{item.label}</div>
                                        <div style={s.infoValue}>{item.value || '—'}</div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Phone Numbers */}
                    {activeTab === 'phones' && (
                        <div style={s.card}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                                <h3 style={{ ...s.cardTitle, margin: 0 }}>Phone Numbers</h3>
                                <button onClick={() => setShowAddPhone(true)} style={s.btn}>
                                    <Plus size={14} /> Add Number
                                </button>
                            </div>

                            {phones.length === 0 ? (
                                <div style={{ color: '#888', fontSize: '13px', padding: '20px 0' }}>
                                    No phone numbers added yet. Add your WhatsApp Business phone number to send messages and broadcasts.
                                </div>
                            ) : (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    {phones.map(p => (
                                        <div key={p.id} style={s.keyRow}>
                                            <div>
                                                <div style={{ fontSize: '13px', fontWeight: '500' }}>{p.display_name || p.phone_number}</div>
                                                <div style={{ fontSize: '12px', color: '#888', fontFamily: 'monospace' }}>{p.phone_number}</div>
                                            </div>
                                            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                                                <span style={{ fontSize: '12px', padding: '2px 8px', borderRadius: '20px', background: p.status === 'active' ? '#dcfce7' : '#fee2e2', color: p.status === 'active' ? '#16a34a' : '#dc2626' }}>
                                                    {p.status}
                                                </span>
                                                <button onClick={() => removePhone(p.id)}
                                                    style={{ padding: '4px 10px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>
                                                    Remove
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {showAddPhone && (
                                <div style={s.modal}>
                                    <div style={s.modalBox}>
                                        <h3 style={{ margin: '0 0 20px', fontSize: '16px' }}>Add Phone Number</h3>
                                        <form onSubmit={addPhone} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                                            <div style={s.field}>
                                                <label style={s.label}>Phone Number ID <span style={{ color: '#888' }}>(from Meta Business Manager)</span></label>
                                                <input placeholder="e.g. 123456789012345"
                                                    value={phoneForm.phone_number_id}
                                                    onChange={e => setPhoneForm({ ...phoneForm, phone_number_id: e.target.value })}
                                                    style={s.input} required />
                                            </div>
                                            <div style={s.field}>
                                                <label style={s.label}>Phone Number</label>
                                                <input placeholder="e.g. 919XXXXXXXXX"
                                                    value={phoneForm.phone_number}
                                                    onChange={e => setPhoneForm({ ...phoneForm, phone_number: e.target.value })}
                                                    style={s.input} required />
                                            </div>
                                            <div style={s.field}>
                                                <label style={s.label}>Display Name <span style={{ color: '#888' }}>(optional)</span></label>
                                                <input placeholder="e.g. Support Line"
                                                    value={phoneForm.display_name}
                                                    onChange={e => setPhoneForm({ ...phoneForm, display_name: e.target.value })}
                                                    style={s.input} />
                                            </div>
                                            <div style={s.field}>
                                                <label style={s.label}>Access Token <span style={{ color: '#888' }}>(WhatsApp Business API token)</span></label>
                                                <input type="password" placeholder="EAAxxxxxxxxxx..."
                                                    value={phoneForm.access_token}
                                                    onChange={e => setPhoneForm({ ...phoneForm, access_token: e.target.value })}
                                                    style={s.input} required />
                                            </div>
                                            <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                                                <button type="button" onClick={() => setShowAddPhone(false)} style={s.cancelBtn}>Cancel</button>
                                                <button type="submit" style={s.btn}>Add Number</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Password */}
                    {activeTab === 'password' && (
                        <div style={s.card}>
                            <h3 style={s.cardTitle}>Change Password</h3>
                            <form onSubmit={changePassword} style={{ display: 'flex', flexDirection: 'column', gap: '14px', maxWidth: '360px' }}>
                                {[
                                    { key: 'current_password', label: 'Current Password' },
                                    { key: 'new_password',     label: 'New Password' },
                                    { key: 'confirm',          label: 'Confirm New Password' },
                                ].map(f => (
                                    <div key={f.key} style={s.field}>
                                        <label style={s.label}>{f.label}</label>
                                        <input type="password" value={pwForm[f.key]}
                                            onChange={e => setPwForm({ ...pwForm, [f.key]: e.target.value })}
                                            style={s.input} required />
                                    </div>
                                ))}
                                <button type="submit" style={s.btn} disabled={loading}>
                                    {loading ? 'Saving...' : 'Change Password'}
                                </button>
                            </form>
                        </div>
                    )}

                    {/* API Keys */}
                    {activeTab === 'apikeys' && (
                        <div style={s.card}>
                            <h3 style={s.cardTitle}>API Keys</h3>

                            {newKey && (
                                <div style={s.keyAlert}>
                                    <div style={{ fontSize: '13px', fontWeight: '600', marginBottom: '6px' }}>
                                        ⚠️ Copy this key now — it won't be shown again!
                                    </div>
                                    <code style={s.keyCode}>{newKey}</code>
                                    <button onClick={() => { navigator.clipboard.writeText(newKey); toast.success('Copied!'); }}
                                        style={{ ...s.btn, marginTop: '8px', fontSize: '12px', padding: '6px 12px' }}>
                                        Copy Key
                                    </button>
                                </div>
                            )}

                            <form onSubmit={createApiKey} style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
                                <input placeholder="Key name (e.g. Production)" value={apiKeyForm.name}
                                    onChange={e => setApiKeyForm({ name: e.target.value })}
                                    style={{ ...s.input, flex: 1 }} required />
                                <button type="submit" style={s.btn}>Generate Key</button>
                            </form>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {apiKeys.length === 0 && (
                                    <div style={{ color: '#888', fontSize: '13px' }}>No API keys yet</div>
                                )}
                                {apiKeys.map(k => (
                                    <div key={k.id} style={s.keyRow}>
                                        <div>
                                            <div style={{ fontSize: '13px', fontWeight: '500' }}>{k.name}</div>
                                            <div style={{ fontSize: '12px', color: '#888', fontFamily: 'monospace' }}>{k.key_prefix}</div>
                                        </div>
                                        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                                            <span style={{ fontSize: '12px', color: '#aaa' }}>
                                                {/* Fixed: last_used_at not last_used */}
                                                {k.last_used_at ? `Last used ${new Date(k.last_used_at).toLocaleDateString()}` : 'Never used'}
                                            </span>
                                            <button onClick={() => revokeKey(k.id)}
                                                style={{ padding: '4px 10px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>
                                                Revoke
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const s = {
    tabNav: { display: 'flex', flexDirection: 'column', gap: '4px', width: '180px', flexShrink: 0 },
    tabBtn: { display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', border: 'none', background: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', color: '#666', textAlign: 'left' },
    tabBtnActive: { background: '#f0fdf4', color: '#25D366', fontWeight: '600' },
    content: { flex: 1 },
    card: { background: '#fff', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
    cardTitle: { margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#111' },
    infoGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
    infoItem: { display: 'flex', flexDirection: 'column', gap: '4px' },
    infoLabel: { fontSize: '12px', color: '#888' },
    infoValue: { fontSize: '14px', fontWeight: '500', color: '#111', textTransform: 'capitalize' },
    btn: { display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 16px', background: '#25D366', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: '500' },
    cancelBtn: { padding: '8px 16px', background: '#f0f0f0', color: '#444', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '13px' },
    field: { display: 'flex', flexDirection: 'column', gap: '5px' },
    label: { fontSize: '12px', fontWeight: '500', color: '#555' },
    input: { padding: '9px 12px', border: '1px solid #e5e7eb', borderRadius: '8px', fontSize: '13px', outline: 'none', boxSizing: 'border-box' },
    keyAlert: { background: '#fef9c3', border: '1px solid #fde047', borderRadius: '8px', padding: '14px', marginBottom: '16px' },
    keyCode: { display: 'block', background: '#fff', padding: '8px', borderRadius: '6px', fontSize: '12px', wordBreak: 'break-all', fontFamily: 'monospace' },
    keyRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', background: '#f9fafb', borderRadius: '8px', border: '1px solid #f0f0f0' },
    modal: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 },
    modalBox: { background: '#fff', borderRadius: '12px', padding: '24px', width: '440px' }
};

export default Settings;