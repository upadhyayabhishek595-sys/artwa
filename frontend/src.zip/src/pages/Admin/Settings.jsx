import { useState, useEffect } from "react";

const API_URL = "http://localhost:5000";

const tabs = [
  { id: "profile", label: "Profile", icon: "👤" },
  { id: "platform", label: "Platform", icon: "⚙️" },
  { id: "plans", label: "Plans", icon: "💎" },
  { id: "whatsapp", label: "WhatsApp", icon: "💬" },
  { id: "security", label: "Security", icon: "🔐" },
];

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState("profile");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [plans, setPlans] = useState([]);
  const [platformSettings, setPlatformSettings] = useState({
    platform_name: "WhatsApp Omnichannel",
    platform_url: "",
    support_email: "",
    trial_days: "14",
    meta_api_version: "v25.0",
    max_retry_attempts: "3",
    rate_limit_per_min: "100",
  });
  const [profile, setProfile] = useState({
    name: "Super Admin",
    email: "admin@artwa.com",
    current_password: "",
    new_password: "",
    confirm_password: "",
  });
  const [whatsapp, setWhatsapp] = useState({
    phone_number_id: "1129576070241902",
    waba_id: "5473062976252355",
    verify_token: "mytoken123",
    meta_api_version: "v25.0",
  });
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    price: "",
    message_limit: "1000",
    contact_limit: "500",
    agent_limit: "2",
    api_access: false,
    webhook_access: false,
    chatbot_access: false,
    broadcast_access: false,
    template_limit: "5",
    phone_number_limit: "1",
    support_level: "basic",
  });

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSave = (section) => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      showToast(`${section} saved successfully!`);
    }, 800);
  };

  const handleAddPlan = () => {
    if (!newPlan.name || !newPlan.price) {
      showToast("Plan name and price required", "error");
      return;
    }
    setPlans([...plans, { ...newPlan, id: Date.now(), status: "active" }]);
    setNewPlan({ ...newPlan, name: "", description: "", price: "" });
    showToast("Plan added!");
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0f1117", color: "#e2e8f0", fontFamily: "'Inter', sans-serif" }}>
      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", top: 24, right: 24, zIndex: 9999,
          background: toast.type === "error" ? "#ef4444" : "#22c55e",
          color: "#fff", padding: "12px 20px", borderRadius: 10,
          fontWeight: 600, fontSize: 14, boxShadow: "0 4px 20px rgba(0,0,0,0.3)"
        }}>
          {toast.type === "error" ? "❌" : "✅"} {toast.msg}
        </div>
      )}

      {/* Header */}
      <div style={{ borderBottom: "1px solid #1e2433", padding: "20px 32px", background: "#0f1117" }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: "#fff" }}>⚙️ Admin Settings</h1>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "#64748b" }}>
          Manage platform configuration, plans, and security
        </p>
      </div>

      <div style={{ display: "flex", height: "calc(100vh - 73px)" }}>
        {/* Sidebar */}
        <div style={{
          width: 220, background: "#0d1018", borderRight: "1px solid #1e2433",
          padding: "16px 0", flexShrink: 0
        }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              width: "100%", textAlign: "left", padding: "12px 20px",
              background: activeTab === tab.id ? "#1a2035" : "transparent",
              border: "none", color: activeTab === tab.id ? "#25d366" : "#94a3b8",
              fontSize: 14, fontWeight: activeTab === tab.id ? 600 : 400,
              cursor: "pointer", display: "flex", alignItems: "center", gap: 10,
              borderLeft: activeTab === tab.id ? "3px solid #25d366" : "3px solid transparent",
              transition: "all 0.15s"
            }}>
              <span>{tab.icon}</span> {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: "auto", padding: 32 }}>

          {/* PROFILE TAB */}
          {activeTab === "profile" && (
            <div>
              <SectionHeader title="Admin Profile" subtitle="Update your name, email and password" />
              <Card>
                <Grid2>
                  <Field label="Full Name">
                    <Input value={profile.name} onChange={e => setProfile({ ...profile, name: e.target.value })} />
                  </Field>
                  <Field label="Email Address">
                    <Input value={profile.email} onChange={e => setProfile({ ...profile, email: e.target.value })} />
                  </Field>
                </Grid2>
                <SaveBtn saving={saving} onClick={() => handleSave("Profile")} />
              </Card>

              <Card style={{ marginTop: 24 }}>
                <SectionHeader title="Change Password" subtitle="Choose a strong password" small />
                <Grid2>
                  <Field label="Current Password">
                    <Input type="password" value={profile.current_password}
                      onChange={e => setProfile({ ...profile, current_password: e.target.value })} />
                  </Field>
                  <Field label="New Password">
                    <Input type="password" value={profile.new_password}
                      onChange={e => setProfile({ ...profile, new_password: e.target.value })} />
                  </Field>
                  <Field label="Confirm New Password">
                    <Input type="password" value={profile.confirm_password}
                      onChange={e => setProfile({ ...profile, confirm_password: e.target.value })} />
                  </Field>
                </Grid2>
                <SaveBtn saving={saving} onClick={() => handleSave("Password")} label="Update Password" />
              </Card>
            </div>
          )}

          {/* PLATFORM TAB */}
          {activeTab === "platform" && (
            <div>
              <SectionHeader title="Platform Settings" subtitle="Configure your platform identity and defaults" />
              <Card>
                <Grid2>
                  <Field label="Platform Name">
                    <Input value={platformSettings.platform_name}
                      onChange={e => setPlatformSettings({ ...platformSettings, platform_name: e.target.value })} />
                  </Field>
                  <Field label="Platform URL">
                    <Input value={platformSettings.platform_url} placeholder="https://yourplatform.com"
                      onChange={e => setPlatformSettings({ ...platformSettings, platform_url: e.target.value })} />
                  </Field>
                  <Field label="Support Email">
                    <Input value={platformSettings.support_email} placeholder="support@yourplatform.com"
                      onChange={e => setPlatformSettings({ ...platformSettings, support_email: e.target.value })} />
                  </Field>
                  <Field label="Trial Days">
                    <Input type="number" value={platformSettings.trial_days}
                      onChange={e => setPlatformSettings({ ...platformSettings, trial_days: e.target.value })} />
                  </Field>
                  <Field label="API Rate Limit (per min)">
                    <Input type="number" value={platformSettings.rate_limit_per_min}
                      onChange={e => setPlatformSettings({ ...platformSettings, rate_limit_per_min: e.target.value })} />
                  </Field>
                  <Field label="Webhook Retry Attempts">
                    <Input type="number" value={platformSettings.max_retry_attempts}
                      onChange={e => setPlatformSettings({ ...platformSettings, max_retry_attempts: e.target.value })} />
                  </Field>
                </Grid2>
                <SaveBtn saving={saving} onClick={() => handleSave("Platform settings")} />
              </Card>
            </div>
          )}

          {/* PLANS TAB */}
          {activeTab === "plans" && (
            <div>
              <SectionHeader title="Subscription Plans" subtitle="Manage plans available to your clients" />

              {/* Existing Plans */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }}>
                {[
                  { name: "Starter", price: "₹999", msgs: "1,000", agents: 2, api: false, color: "#3b82f6" },
                  { name: "Business", price: "₹2,999", msgs: "10,000", agents: 5, api: true, color: "#25d366" },
                  { name: "Enterprise", price: "₹9,999", msgs: "Unlimited", agents: 20, api: true, color: "#f59e0b" },
                ].map(plan => (
                  <div key={plan.name} style={{
                    background: "#131929", borderRadius: 12,
                    border: `1px solid ${plan.color}33`, padding: 20
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                      <span style={{ fontWeight: 700, color: "#fff" }}>{plan.name}</span>
                      <span style={{
                        background: "#0f1117", borderRadius: 20, padding: "3px 10px",
                        fontSize: 12, color: "#22c55e"
                      }}>Active</span>
                    </div>
                    <div style={{ fontSize: 28, fontWeight: 800, color: plan.color, marginBottom: 12 }}>
                      {plan.price}<span style={{ fontSize: 13, color: "#64748b", fontWeight: 400 }}>/mo</span>
                    </div>
                    <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.8 }}>
                      <div>💬 {plan.msgs} messages/month</div>
                      <div>👥 {plan.agents} agents</div>
                      <div>{plan.api ? "✅" : "❌"} API Access</div>
                    </div>
                    <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                      <ActionBtn color="#3b82f6" onClick={() => showToast(`${plan.name} plan edit coming soon`)}>Edit</ActionBtn>
                      <ActionBtn color="#ef4444" onClick={() => showToast(`${plan.name} deactivated`)}>Deactivate</ActionBtn>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add New Plan */}
              <Card>
                <SectionHeader title="Add New Plan" subtitle="Create a custom plan for clients" small />
                <Grid2>
                  <Field label="Plan Name"><Input value={newPlan.name} onChange={e => setNewPlan({ ...newPlan, name: e.target.value })} placeholder="e.g. Premium" /></Field>
                  <Field label="Price (₹/month)"><Input type="number" value={newPlan.price} onChange={e => setNewPlan({ ...newPlan, price: e.target.value })} /></Field>
                  <Field label="Message Limit"><Input type="number" value={newPlan.message_limit} onChange={e => setNewPlan({ ...newPlan, message_limit: e.target.value })} /></Field>
                  <Field label="Agent Limit"><Input type="number" value={newPlan.agent_limit} onChange={e => setNewPlan({ ...newPlan, agent_limit: e.target.value })} /></Field>
                  <Field label="Contact Limit"><Input type="number" value={newPlan.contact_limit} onChange={e => setNewPlan({ ...newPlan, contact_limit: e.target.value })} /></Field>
                  <Field label="Template Limit"><Input type="number" value={newPlan.template_limit} onChange={e => setNewPlan({ ...newPlan, template_limit: e.target.value })} /></Field>
                </Grid2>

                {/* Feature Toggles */}
                <div style={{ marginTop: 20, display: "flex", flexWrap: "wrap", gap: 16 }}>
                  {[
                    { key: "api_access", label: "API Access" },
                    { key: "webhook_access", label: "Webhooks" },
                    { key: "chatbot_access", label: "Chatbot Builder" },
                    { key: "broadcast_access", label: "Broadcasts" },
                  ].map(feature => (
                    <Toggle key={feature.key} label={feature.label}
                      value={newPlan[feature.key]}
                      onChange={v => setNewPlan({ ...newPlan, [feature.key]: v })} />
                  ))}
                </div>

                <Field label="Description" style={{ marginTop: 16 }}>
                  <textarea value={newPlan.description}
                    onChange={e => setNewPlan({ ...newPlan, description: e.target.value })}
                    placeholder="Brief plan description..."
                    style={{
                      width: "100%", background: "#0f1117", border: "1px solid #1e2433",
                      borderRadius: 8, padding: "10px 14px", color: "#e2e8f0",
                      fontSize: 14, resize: "vertical", minHeight: 80, boxSizing: "border-box"
                    }} />
                </Field>

                <button onClick={handleAddPlan} style={{
                  marginTop: 16, background: "#25d366", border: "none",
                  color: "#fff", padding: "10px 24px", borderRadius: 8,
                  fontWeight: 600, fontSize: 14, cursor: "pointer"
                }}>+ Add Plan</button>
              </Card>
            </div>
          )}

          {/* WHATSAPP TAB */}
          {activeTab === "whatsapp" && (
            <div>
              <SectionHeader title="WhatsApp API Configuration" subtitle="Meta API credentials and webhook settings" />
              <Card>
                <Grid2>
                  <Field label="Phone Number ID">
                    <Input value={whatsapp.phone_number_id}
                      onChange={e => setWhatsapp({ ...whatsapp, phone_number_id: e.target.value })} />
                  </Field>
                  <Field label="WhatsApp Business Account ID">
                    <Input value={whatsapp.waba_id}
                      onChange={e => setWhatsapp({ ...whatsapp, waba_id: e.target.value })} />
                  </Field>
                  <Field label="Verify Token">
                    <Input value={whatsapp.verify_token}
                      onChange={e => setWhatsapp({ ...whatsapp, verify_token: e.target.value })} />
                  </Field>
                  <Field label="Meta API Version">
                    <Input value={whatsapp.meta_api_version}
                      onChange={e => setWhatsapp({ ...whatsapp, meta_api_version: e.target.value })} />
                  </Field>
                </Grid2>

                {/* Webhook URL Display */}
                <div style={{ marginTop: 20, background: "#0f1117", borderRadius: 8, padding: 16, border: "1px solid #1e2433" }}>
                  <div style={{ fontSize: 12, color: "#64748b", marginBottom: 6 }}>Your Webhook URL (set this in Meta Dashboard)</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <code style={{ flex: 1, fontSize: 13, color: "#25d366" }}>
                      http://localhost:5000/webhook
                    </code>
                    <button onClick={() => {
                      navigator.clipboard.writeText("http://localhost:5000/webhook");
                      showToast("Webhook URL copied!");
                    }} style={{
                      background: "#1e2433", border: "none", color: "#94a3b8",
                      padding: "6px 12px", borderRadius: 6, cursor: "pointer", fontSize: 12
                    }}>Copy</button>
                  </div>
                </div>

                <SaveBtn saving={saving} onClick={() => handleSave("WhatsApp settings")} />
              </Card>

              {/* API Status */}
              <Card style={{ marginTop: 24 }}>
                <SectionHeader title="API Connection Status" subtitle="Live status of your Meta API connection" small />
                <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                  {[
                    { label: "Meta API", status: "Connected", color: "#22c55e" },
                    { label: "Webhook", status: "Verified", color: "#22c55e" },
                    { label: "Phone Number", status: "Active", color: "#22c55e" },
                    { label: "App Status", status: "Unpublished", color: "#f59e0b" },
                  ].map(item => (
                    <div key={item.label} style={{
                      background: "#0f1117", borderRadius: 10, padding: "12px 20px",
                      border: `1px solid ${item.color}33`, minWidth: 140
                    }}>
                      <div style={{ fontSize: 12, color: "#64748b" }}>{item.label}</div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: item.color, marginTop: 4 }}>
                        ● {item.status}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* SECURITY TAB */}
          {activeTab === "security" && (
            <div>
              <SectionHeader title="Security Settings" subtitle="Control access, sessions and authentication" />
              <Card>
                <SectionHeader title="JWT Configuration" subtitle="Token expiry and security settings" small />
                <Grid2>
                  <Field label="Access Token Expiry">
                    <select style={{
                      width: "100%", background: "#0f1117", border: "1px solid #1e2433",
                      borderRadius: 8, padding: "10px 14px", color: "#e2e8f0", fontSize: 14
                    }}>
                      <option>7 days</option>
                      <option>1 day</option>
                      <option>30 days</option>
                    </select>
                  </Field>
                  <Field label="Refresh Token Expiry">
                    <select style={{
                      width: "100%", background: "#0f1117", border: "1px solid #1e2433",
                      borderRadius: 8, padding: "10px 14px", color: "#e2e8f0", fontSize: 14
                    }}>
                      <option>30 days</option>
                      <option>7 days</option>
                      <option>90 days</option>
                    </select>
                  </Field>
                </Grid2>
              </Card>

              <Card style={{ marginTop: 24 }}>
                <SectionHeader title="API Rate Limiting" subtitle="Protect your platform from abuse" small />
                <Grid2>
                  <Field label="Requests per minute (default)">
                    <Input type="number" defaultValue={100} />
                  </Field>
                  <Field label="Max API keys per client">
                    <Input type="number" defaultValue={5} />
                  </Field>
                </Grid2>
                <SaveBtn saving={saving} onClick={() => handleSave("Security settings")} />
              </Card>

              <Card style={{ marginTop: 24, border: "1px solid #ef444433" }}>
                <SectionHeader title="Danger Zone" subtitle="Irreversible actions — proceed with caution" small />
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 8 }}>
                  <ActionBtn color="#ef4444" onClick={() => showToast("Feature coming soon", "error")}>
                    🗑️ Clear All Logs
                  </ActionBtn>
                  <ActionBtn color="#ef4444" onClick={() => showToast("Feature coming soon", "error")}>
                    🔄 Reset Platform Settings
                  </ActionBtn>
                </div>
              </Card>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// =============================================
// REUSABLE COMPONENTS
// =============================================

function SectionHeader({ title, subtitle, small }) {
  return (
    <div style={{ marginBottom: small ? 16 : 24 }}>
      <h2 style={{ margin: 0, fontSize: small ? 16 : 20, fontWeight: 700, color: "#fff" }}>{title}</h2>
      {subtitle && <p style={{ margin: "4px 0 0", fontSize: 13, color: "#64748b" }}>{subtitle}</p>}
    </div>
  );
}

function Card({ children, style = {} }) {
  return (
    <div style={{
      background: "#131929", borderRadius: 12,
      border: "1px solid #1e2433", padding: 24, ...style
    }}>
      {children}
    </div>
  );
}

function Grid2({ children }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
      {children}
    </div>
  );
}

function Field({ label, children, style = {} }) {
  return (
    <div style={style}>
      <label style={{ display: "block", fontSize: 12, color: "#64748b", marginBottom: 6, fontWeight: 500 }}>
        {label}
      </label>
      {children}
    </div>
  );
}

function Input({ type = "text", value, onChange, placeholder, defaultValue }) {
  return (
    <input type={type} value={value} onChange={onChange}
      placeholder={placeholder} defaultValue={defaultValue}
      style={{
        width: "100%", background: "#0f1117", border: "1px solid #1e2433",
        borderRadius: 8, padding: "10px 14px", color: "#e2e8f0",
        fontSize: 14, boxSizing: "border-box", outline: "none"
      }} />
  );
}

function SaveBtn({ saving, onClick, label = "Save Changes" }) {
  return (
    <button onClick={onClick} disabled={saving} style={{
      marginTop: 20, background: saving ? "#1e2433" : "#25d366",
      border: "none", color: "#fff", padding: "10px 28px",
      borderRadius: 8, fontWeight: 600, fontSize: 14,
      cursor: saving ? "not-allowed" : "pointer", transition: "all 0.2s"
    }}>
      {saving ? "Saving..." : `💾 ${label}`}
    </button>
  );
}

function ActionBtn({ children, color, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: `${color}15`, border: `1px solid ${color}44`,
      color, padding: "8px 16px", borderRadius: 8,
      fontWeight: 600, fontSize: 13, cursor: "pointer"
    }}>
      {children}
    </button>
  );
}

function Toggle({ label, value, onChange }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}
      onClick={() => onChange(!value)}>
      <div style={{
        width: 44, height: 24, borderRadius: 12, position: "relative",
        background: value ? "#25d366" : "#1e2433", transition: "background 0.2s"
      }}>
        <div style={{
          width: 18, height: 18, borderRadius: "50%", background: "#fff",
          position: "absolute", top: 3, left: value ? 23 : 3, transition: "left 0.2s"
        }} />
      </div>
      <span style={{ fontSize: 13, color: "#94a3b8" }}>{label}</span>
    </div>
  );
}