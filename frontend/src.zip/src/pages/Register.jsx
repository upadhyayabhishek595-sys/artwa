import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MessageSquare } from 'lucide-react';
import api from '../api/axios';
import toast from 'react-hot-toast';

const Register = () => {
    const [form, setForm] = useState({ name: '', business_name: '', email: '', password: '', phone: '' });
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const res = await api.post('/auth/client/register', form);
            localStorage.setItem('token', res.data.token);
            localStorage.setItem('user', JSON.stringify({ ...res.data.user, type: 'client' }));
            toast.success('Account created! 14-day trial started.');
            navigate('/dashboard');
        } catch (err) {
            toast.error(err.response?.data?.message || 'Registration failed');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={s.page}>
            <div style={s.card}>
                <div style={s.logo}>
                    <MessageSquare size={28} color="#25D366" />
                    <h1 style={s.title}>Artwa</h1>
                </div>
                <p style={s.sub}>Create your account — 14 days free</p>

                <form onSubmit={handleSubmit} style={s.form}>
                    {[
                        { key: 'name',          label: 'Your Name',      placeholder: 'John Doe',           type: 'text' },
                        { key: 'business_name', label: 'Business Name',  placeholder: 'Acme Inc.',          type: 'text' },
                        { key: 'email',         label: 'Email',          placeholder: 'you@example.com',    type: 'email' },
                        { key: 'phone',         label: 'Phone',          placeholder: '+91 9999999999',     type: 'text' },
                        { key: 'password',      label: 'Password',       placeholder: 'Min 8 characters',   type: 'password' },
                    ].map(f => (
                        <div key={f.key} style={s.field}>
                            <label style={s.label}>{f.label}</label>
                            <input type={f.type} placeholder={f.placeholder}
                                value={form[f.key]}
                                onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                                style={s.input}
                                required={f.key !== 'phone'} />
                        </div>
                    ))}
                    <button type="submit" style={s.btn} disabled={loading}>
                        {loading ? 'Creating account...' : 'Start Free Trial'}
                    </button>
                </form>

                <p style={s.footer}>
                    Already have an account? <Link to="/login" style={s.link}>Login</Link>
                </p>
            </div>
        </div>
    );
};

const s = {
    page: { minHeight: '100vh', background: '#f7f8fa', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' },
    card: { background: '#fff', borderRadius: '16px', padding: '40px', width: '100%', maxWidth: '420px', boxShadow: '0 4px 24px rgba(0,0,0,0.08)' },
    logo: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' },
    title: { fontSize: '22px', fontWeight: '700', color: '#111', margin: 0 },
    sub: { color: '#888', fontSize: '13px', marginBottom: '28px', marginTop: '4px' },
    form: { display: 'flex', flexDirection: 'column', gap: '14px' },
    field: { display: 'flex', flexDirection: 'column', gap: '6px' },
    label: { fontSize: '13px', fontWeight: '500', color: '#444' },
    input: { padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: '8px', fontSize: '14px', outline: 'none', color: '#111' },
    btn: { padding: '12px', background: '#25D366', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '14px', fontWeight: '600', cursor: 'pointer', marginTop: '4px' },
    footer: { textAlign: 'center', fontSize: '13px', color: '#888', marginTop: '20px', marginBottom: 0 },
    link: { color: '#25D366', textDecoration: 'none', fontWeight: '500' }
};

export default Register;